document.addEventListener('DOMContentLoaded', function() {
    // Thumbnail Gallery
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.getElementById('main-image');
    
    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', function() {
            // Remove active class from all thumbnails
            thumbnails.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked thumbnail
            this.classList.add('active');
            
            // Change main image
            const newImageSrc = this.getAttribute('data-image');
            mainImage.style.opacity = 0;
            
            setTimeout(() => {
                mainImage.src = newImageSrc;
                mainImage.style.opacity = 1;
            }, 200);
        });
    });
    
    // Image Navigation
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    
    prevBtn.addEventListener('click', function() {
        const activeThumb = document.querySelector('.thumbnail.active');
        const prevThumb = activeThumb.previousElementSibling || thumbnails[thumbnails.length - 1];
        prevThumb.click();
    });
    
    nextBtn.addEventListener('click', function() {
        const activeThumb = document.querySelector('.thumbnail.active');
        const nextThumb = activeThumb.nextElementSibling || thumbnails[0];
        nextThumb.click();
    });
    
    // Weight Selection
    const weightOptions = document.querySelectorAll('.weight-option');
    const priceDisplay = document.querySelector('.price');
    
    weightOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            weightOptions.forEach(opt => opt.classList.remove('active'));
            
            // Add active class to clicked option
            this.classList.add('active');
            
            // Update price
            const newPrice = this.getAttribute('data-price');
            priceDisplay.textContent = newPrice;
            
            // Add animation
            priceDisplay.style.transform = 'scale(1.1)';
            setTimeout(() => {
                priceDisplay.style.transform = 'scale(1)';
            }, 200);
        });
    });
    
    // Quantity Selector
    const minusBtn = document.querySelector('.minus');
    const plusBtn = document.querySelector('.plus');
    const quantityInput = document.querySelector('.quantity-input');
    
    minusBtn.addEventListener('click', function() {
        let currentValue = parseInt(quantityInput.value);
        if (currentValue > 1) {
            quantityInput.value = currentValue - 1;
        }
    });
    
    plusBtn.addEventListener('click', function() {
        let currentValue = parseInt(quantityInput.value);
        if (currentValue < 10) {
            quantityInput.value = currentValue + 1;
        }
    });
    
    // Tab System
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Remove active class from all buttons and contents
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Add to Cart Button
    const addToCartBtn = document.querySelector('.add-to-cart');
    
    addToCartBtn.addEventListener('click', function() {
        const activeWeight = document.querySelector('.weight-option.active');
        const quantity = quantityInput.value;
        
        if (!activeWeight) {
            alert('Prosím vyberte množství');
            return;
        }
        
        const weight = activeWeight.getAttribute('data-weight');
        const price = activeWeight.getAttribute('data-price');
        
        // Here you would normally add to cart
        // For now we'll just show a confirmation
        this.innerHTML = '<i class="fas fa-check"></i> Přidáno do košíku';
        this.style.backgroundColor = '#4CAF50';
        
        setTimeout(() => {
            this.innerHTML = '<i class="fas fa-shopping-cart"></i> Přidat do košíku';
            this.style.backgroundColor = '';
        }, 2000);
        
        console.log(`Added to cart: ${weight}g, Quantity: ${quantity}, Price: ${price} Kč`);
    });
    
    // Initialize first weight option as active
    if (weightOptions.length > 0) {
        weightOptions[0].click();
    }
    
    // Keyboard navigation for image gallery
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            prevBtn.click();
        } else if (e.key === 'ArrowRight') {
            nextBtn.click();
        }
    });
});