/**
 * Green.js - JavaScript functionality for Zelený Kratom product page
 */
document.addEventListener('DOMContentLoaded', function() {
    // Cache DOM elements
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.getElementById('main-image');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    const weightOptions = document.querySelectorAll('.weight-option');
    const priceDisplay = document.querySelector('.price');
    const minusBtn = document.querySelector('.minus');
    const plusBtn = document.querySelector('.plus');
    const quantityInput = document.querySelector('.quantity-input');
    const addToCartBtn = document.querySelector('.add-to-cart');
    const cartNotification = document.getElementById('cart-notification');
    
    // ====== Image Gallery Functions ======
    
    /**
     * Handle thumbnail click to change main image
     */
    function initThumbnailGallery() {
        thumbnails.forEach(thumb => {
            thumb.addEventListener('click', function() {
                // Update active thumbnail
                thumbnails.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                // Update main image with fade effect
                const newImageSrc = this.getAttribute('data-image');
                mainImage.style.opacity = 0;
                
                setTimeout(() => {
                    mainImage.src = newImageSrc;
                    mainImage.style.opacity = 1;
                }, 200);
            });
        });
    }
    
    /**
     * Initialize arrow navigation for gallery
     */
    function initGalleryNavigation() {
        // Navigate to previous image
        prevBtn.addEventListener('click', function() {
            const activeThumb = document.querySelector('.thumbnail.active');
            const prevThumb = activeThumb.previousElementSibling || thumbnails[thumbnails.length - 1];
            prevThumb.click();
        });
        
        // Navigate to next image
        nextBtn.addEventListener('click', function() {
            const activeThumb = document.querySelector('.thumbnail.active');
            const nextThumb = activeThumb.nextElementSibling || thumbnails[0];
            nextThumb.click();
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowLeft') {
                prevBtn.click();
            } else if (e.key === 'ArrowRight') {
                nextBtn.click();
            }
        });
    }
    
    // ====== Product Options Functions ======
    
    /**
     * Initialize weight option selection
     */
    function initWeightSelection() {
        weightOptions.forEach(option => {
            option.addEventListener('click', function() {
                // Update active weight option
                weightOptions.forEach(opt => opt.classList.remove('active'));
                this.classList.add('active');
                
                // Update price with animation
                const newPrice = this.getAttribute('data-price');
                updatePrice(newPrice);
            });
        });
    }
    
    /**
     * Update price with animation
     */
    function updatePrice(newPrice) {
        // Animate price change
        priceDisplay.style.transform = 'scale(1.1)';
        priceDisplay.textContent = newPrice;
        
        setTimeout(() => {
            priceDisplay.style.transform = 'scale(1)';
        }, 200);
    }
    
    /**
     * Initialize quantity selector
     */
    function initQuantitySelector() {
        // Decrease quantity
        minusBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue > 1) {
                quantityInput.value = currentValue - 1;
            }
        });
        
        // Increase quantity
        plusBtn.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue < 10) {
                quantityInput.value = currentValue + 1;
            }
        });
        
        // Validate input manually
        quantityInput.addEventListener('change', function() {
            let value = parseInt(this.value);
            if (isNaN(value) || value < 1) {
                this.value = 1;
            } else if (value > 10) {
                this.value = 10;
            }
        });
    }
    
    // ====== Cart Functions ======
    
    /**
     * Get cart from cookies
     */
    function getCartFromCookies() {
        const cookieValue = document.cookie
            .split('; ')
            .find(row => row.startsWith('cart='));
        
        return cookieValue ? JSON.parse(decodeURIComponent(cookieValue.split('=')[1])) : [];
    }
    
    /**
     * Save cart to cookies
     */
    function saveCartToCookies(cart) {
        const date = new Date();
        date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 days expiration
        document.cookie = `cart=${encodeURIComponent(JSON.stringify(cart))}; expires=${date.toUTCString()}; path=/; samesite=lax`;
    }
    
    /**
     * Update cart counter
     */
    function updateCartCounter() {
        const cart = getCartFromCookies();
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        document.querySelectorAll('.cart-counter').forEach(counter => {
            counter.textContent = totalItems;
        });
    }
    
    /**
     * Add current product to cart
     */
    function addToCart() {
        const selectedWeight = document.querySelector('.weight-option.active').dataset.weight;
        const selectedPrice = document.querySelector('.weight-option.active').dataset.price;
        const quantity = parseInt(document.querySelector('.quantity-input').value);
        const productName = document.querySelector('h1').textContent.trim();
        const productImage = document.getElementById('main-image').src;
        
        const cart = getCartFromCookies();
        
        // Check if this product with same weight is already in cart
        const existingItemIndex = cart.findIndex(item => 
            item.name === productName && item.weight === selectedWeight
        );
        
        if (existingItemIndex !== -1) {
            // Update quantity if item exists
            cart[existingItemIndex].quantity += quantity;
        } else {
            // Add new item to cart
            cart.push({
                name: productName,
                weight: selectedWeight,
                price: selectedPrice,
                quantity: quantity,
                image: productImage
            });
        }
        
        saveCartToCookies(cart);
        updateCartCounter();
        
        // Show notification
        showNotification();
    }
    
    /**
     * Show notification toast
     */
    function showNotification() {
        cartNotification.classList.add('show');
        
        setTimeout(() => {
            cartNotification.classList.remove('show');
        }, 3000);
    }
    
    // ====== Initialization ======
    
    /**
     * Initialize all functionality
     */
    function init() {
        // Initialize gallery
        initThumbnailGallery();
        initGalleryNavigation();
        
        // Initialize product options
        initWeightSelection();
        initQuantitySelector();
        
        // Set default weight option (100g)
        if (weightOptions.length > 0) {
            weightOptions[1].click();
        }
        
        // Initialize cart
        updateCartCounter();
        
        // Add to cart button
        addToCartBtn.addEventListener('click', addToCart);
        
        // Add lazy loading to images that are not visible initially
        const lazyImages = document.querySelectorAll('.thumbnail:not(.active) img');
        if ('loading' in HTMLImageElement.prototype) {
            lazyImages.forEach(img => {
                img.loading = 'lazy';
            });
        }
        
        // Initialize animations for effect bars
        animateEffectBars();
    }
    
    /**
     * Animate effect bars on scroll
     */
    function animateEffectBars() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const bars = entry.target.querySelectorAll('.bar');
                    bars.forEach(bar => {
                        const width = bar.style.getPropertyValue('--width');
                        bar.style.setProperty('--width', '0');
                        
                        setTimeout(() => {
                            bar.style.setProperty('--width', width);
                        }, 100);
                    });
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        const effectContainer = document.querySelector('.effect-indicators-container');
        if (effectContainer) {
            observer.observe(effectContainer);
        }
    }
    
    // Initialize everything
    init();
});