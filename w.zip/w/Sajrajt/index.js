// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});


// FAQ Toggle
document.querySelectorAll('.faq-item').forEach(item => {
    item.addEventListener('click', function() {
        const allItems = document.querySelectorAll('.faq-item');
        
        // Zavřít všechny ostatní položky
        allItems.forEach(otherItem => {
            if (otherItem !== this) {
                otherItem.classList.remove('active');
                const otherIcon = otherItem.querySelector('i');
                otherIcon.style.transform = 'rotate(0deg)';
                otherIcon.style.color = '#4CAF50';
            }
        });

        // Otevřít/zavřít aktuální položku
        const isActive = this.classList.toggle('active');
        const icon = this.querySelector('i');
        
        if (isActive) {
            icon.style.transform = 'rotate(180deg)';
            icon.style.color = '#FFD700';
        } else {
            icon.style.transform = 'rotate(0deg)';
            icon.style.color = '#4CAF50';
        }
    });
});

// Animace tlačítka
document.querySelectorAll('.quantum-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        this.classList.add('loading');
        
        setTimeout(() => {
            this.classList.remove('loading');
            // Zde přidejte odeslání formuláře
        }, 2000);
    });
});

// Interaktivní inputy
document.querySelectorAll('.form-input').forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.classList.add('active');
    });
    
    input.addEventListener('blur', function() {
        if(!this.value) this.parentElement.classList.remove('active');
    });
});

function fixHeight() {
    document.body.style.height = "auto"; // Resetuje výšku
    setTimeout(() => {
        document.body.style.height = document.documentElement.scrollHeight + "px";
    }, 50);
}

// Spustí se při změně velikosti
window.addEventListener("resize", fixHeight);
window.addEventListener("load", fixHeight);

// JavaScript pro listy
document.addEventListener('DOMContentLoaded', () => {
    const leavesContainer = document.querySelector('.kratom-leaves-container');
    const heroSection = document.querySelector('.hero');

    function createLeaves() {
        const numberOfLeaves = 120; // Počet listů
        for (let i = 0; i < numberOfLeaves; i++) {
            const leaf = document.createElement('div');
            leaf.classList.add('kratom-leaf');
            leaf.textContent = '🍃';
            leavesContainer.appendChild(leaf);
        }
    }

    function updateLeaves() {
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        
        // Listy budou padat přes celou viditelnou oblast
        leavesContainer.style.height = `${documentHeight}px`;
        
        const leaves = document.querySelectorAll('.kratom-leaf');
        leaves.forEach((leaf, index) => {
            const randomStart = Math.random() * 100;
            const randomDelay = index * 0.1 + Math.random() * 0.5;
            
            leaf.style.setProperty('--start-position', `${randomStart}%`);
            leaf.style.setProperty('--end-position', `${documentHeight + 100}px`);
            leaf.style.setProperty('--animation-delay', `${randomDelay}s`);
            leaf.style.animationDuration = `${12 + Math.random() * 4}s`;
        });
    }

    createLeaves();
    setTimeout(updateLeaves, 100); 
    window.addEventListener('resize', updateLeaves);
});