document.addEventListener('DOMContentLoaded', function() {
    // Load cart from cookies and display items
    const cartItemsContainer = document.querySelector('#cart-items-container');
    const cart = getCartFromCookies();
    
    // If cart is empty, show empty state
    if (cart.length === 0) {
        showEmptyCart();
        return;
    }
    
    // Render cart items
    renderCartItems(cart);
    
    // Initialize cart functionality
    initCartFunctionality();
    
    function getCartFromCookies() {
        const cookieValue = document.cookie
            .split('; ')
            .find(row => row.startsWith('cart='));
        
        return cookieValue ? JSON.parse(decodeURIComponent(cookieValue.split('=')[1])) : [];
    }
    
    function saveCartToCookies(cart) {
        const date = new Date();
        date.setTime(date.getTime() + (30 * 24 * 60 * 60 * 1000)); // 30 days expiration
        document.cookie = `cart=${encodeURIComponent(JSON.stringify(cart))}; expires=${date.toUTCString()}; path=/`;
    }
    
    function renderCartItems(cart) {
        // Clear existing items (except form sections)
        const formSections = document.querySelectorAll('.billing-section, .delivery-section, .payment-section');
        cartItemsContainer.innerHTML = '';
        
        // Add cart items
        cart.forEach((item, index) => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item fade-in';
            cartItem.innerHTML = `
                <div class="item-image">
                    <img src="${item.image}" alt="${item.name}">
                </div>
                <div class="item-details">
                    <h3>${item.name} - ${item.weight}g</h3>
                    <p class="item-price">${item.price} Kč</p>
                    <div class="quantity-selector">
                        <button class="quantity-btn btn-decrease"><i class="fas fa-minus"></i></button>
                        <span class="quantity">${item.quantity}</span>
                        <button class="quantity-btn btn-increase"><i class="fas fa-plus"></i></button>
                    </div>
                </div>
                <button class="remove-btn" aria-label="Odstranit produkt" data-index="${index}">
                    <i class="fas fa-trash-alt"></i>
                </button>
            `;
            cartItemsContainer.appendChild(cartItem);
        });
        
        // Add form sections back
        formSections.forEach(section => cartItemsContainer.appendChild(section));
        
        updateCartTotal();
    }
    
    function initCartFunctionality() {
        // Event delegation for dynamic elements
        document.addEventListener('click', function(e) {
            // Decrease quantity
            if (e.target.classList.contains('btn-decrease') || e.target.parentElement.classList.contains('btn-decrease')) {
                const btn = e.target.classList.contains('btn-decrease') ? e.target : e.target.parentElement;
                const index = btn.closest('.cart-item').querySelector('.remove-btn').dataset.index;
                updateQuantity(index, -1);
            }
            
            // Increase quantity
            if (e.target.classList.contains('btn-increase') || e.target.parentElement.classList.contains('btn-increase')) {
                const btn = e.target.classList.contains('btn-increase') ? e.target : e.target.parentElement;
                const index = btn.closest('.cart-item').querySelector('.remove-btn').dataset.index;
                updateQuantity(index, 1);
            }
            
            // Remove item
            if (e.target.classList.contains('remove-btn') || e.target.parentElement.classList.contains('remove-btn')) {
                const btn = e.target.classList.contains('remove-btn') ? e.target : e.target.parentElement;
                const index = btn.dataset.index;
                removeItem(index);
            }
        });

        // Delivery options change
        document.querySelectorAll('.delivery-options input').forEach(option => {
            option.addEventListener('change', () => {
                const subtotal = parseFloat(document.querySelector('.summary-value').textContent.replace(' Kč', ''));
                updateTotalPrice(subtotal);
            });
        });
        
        // Payment options change
        document.querySelectorAll('.payment-options input').forEach(option => {
            option.addEventListener('change', () => {
                const subtotal = parseFloat(document.querySelector('.summary-value').textContent.replace(' Kč', ''));
                updateTotalPrice(subtotal);
            });
        });
        
        // Coupon button
        const couponBtn = document.querySelector('.coupon-btn');
        if (couponBtn) {
            couponBtn.addEventListener('click', applyCoupon);
            
            // Also apply coupon on Enter key
            document.querySelector('.coupon-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    applyCoupon();
                }
            });
        }
        
        // Checkout button
        const checkoutBtn = document.querySelector('.checkout-btn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', processCheckout);
        }
    }
    
    function updateQuantity(index, change) {
        const cart = getCartFromCookies();
        cart[index].quantity += change;
        
        if (cart[index].quantity < 1) cart[index].quantity = 1;
        
        saveCartToCookies(cart);
        renderCartItems(cart);
    }
    
    function removeItem(index) {
        const cart = getCartFromCookies();
        cart.splice(index, 1);
        
        saveCartToCookies(cart);
        
        if (cart.length === 0) {
            showEmptyCart();
        } else {
            renderCartItems(cart);
        }
    }
    
    function updateCartTotal() {
        const cart = getCartFromCookies();
        let subtotal = 0;
        
        cart.forEach(item => {
            subtotal += parseInt(item.price) * item.quantity;
        });
        
        document.querySelector('.summary-value').textContent = subtotal + ' Kč';
        updateTotalPrice(subtotal);
    }
    
    function updateTotalPrice(subtotal) {
        const deliveryOption = document.querySelector('.delivery-options input:checked');
        let deliveryPrice = 0;
        
        if (deliveryOption) {
            const priceText = deliveryOption.closest('.delivery-option').querySelector('.option-price').textContent;
            deliveryPrice = priceText === 'Zdarma' ? 0 : parseInt(priceText);
        }
        
        // Check for payment method fee (dobírka)
        const paymentOption = document.querySelector('.payment-options input:checked');
        let paymentFee = 0;
        
        if (paymentOption && paymentOption.closest('.payment-option').querySelector('.option-price')) {
            const feeText = paymentOption.closest('.payment-option').querySelector('.option-price').textContent;
            paymentFee = feeText === 'Zdarma' ? 0 : parseInt(feeText.replace('+', ''));
        }
        
        const total = subtotal + deliveryPrice + paymentFee;
        document.querySelector('.total-price').innerHTML = total + ' Kč <span>Celková cena včetně DPH</span>';
    }
    
    function showEmptyCart() {
        const cartSection = document.querySelector('.cart-section');
        cartSection.innerHTML = `
            <div class="empty-cart fade-in">
                <i class="fas fa-shopping-cart"></i>
                <h3>Váš košík je prázdný</h3>
                <p>Zatím nemáte v košíku žádné produkty. Prohlédněte si naši nabídku a přidejte nějaké!</p>
                <a href="../index.html" class="btn">Zpět do obchodu</a>
            </div>
        `;
    }
    
    function applyCoupon() {
        const couponInput = document.querySelector('.coupon-input');
        const discountElement = document.querySelector('.discount-row .summary-value');
        
        if (couponInput.value === 'SAJRAJT10') {
            const subtotal = parseFloat(document.querySelector('.summary-value').textContent.replace(' Kč', ''));
            const discount = subtotal * 0.1; // 10% discount
            const total = subtotal - discount;
            
            discountElement.textContent = '-' + discount.toFixed(0) + ' Kč';
            document.querySelector('.total-price').innerHTML = total.toFixed(0) + ' Kč <span>Celková cena včetně DPH</span>';
            
            // Show success
            couponInput.style.borderColor = 'var(--success)';
            setTimeout(() => {
                couponInput.style.borderColor = '';
            }, 2000);
        } else {
            // Show error
            couponInput.style.animation = 'shake 0.5s';
            setTimeout(() => {
                couponInput.style.animation = '';
            }, 500);
        }
    }
    
    function processCheckout() {
        const checkoutBtn = document.querySelector('.checkout-btn');
        const originalText = checkoutBtn.innerHTML;
        checkoutBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Zpracováváme...';
        checkoutBtn.disabled = true;
        
        // Validate form
        const requiredFields = document.querySelectorAll('input[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.style.borderColor = 'var(--error)';
                isValid = false;
            }
        });
        
        if (!isValid) {
            alert('Vyplňte prosím všechny povinné údaje!');
            checkoutBtn.innerHTML = originalText;
            checkoutBtn.disabled = false;
            return;
        }
        
        // Simulate processing
        setTimeout(() => {
            alert('Objednávka byla úspěšně odeslána!');
            
            // Clear cart after successful order
            document.cookie = 'cart=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
            
            // Redirect to homepage
            window.location.href = '../index.html';
        }, 1500);
    }
});

// Add shake animation to head
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        20%, 60% { transform: translateX(-5px); }
        40%, 80% { transform: translateX(5px); }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease-out;
    }
`;
document.head.appendChild(style);